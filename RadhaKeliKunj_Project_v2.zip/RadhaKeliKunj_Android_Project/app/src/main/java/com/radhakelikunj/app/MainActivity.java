package com.radhakelikunj.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private int count = 0;
    private TextView counter;

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }

    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(12), dp(8), dp(12), dp(8));
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(139, 48, 91)));
        return b;
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(107,36,72));
        getWindow().setNavigationBarColor(Color.rgb(62,24,48));

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(14), dp(16), dp(24));
        page.setBackgroundColor(Color.rgb(255, 246, 249));

        page.addView(label("🌸 ରାଧା କେଳି କୁଞ୍ଜ 🌸", 26, Color.rgb(107,36,72)));
        page.addView(label("ଶ୍ରୀ ରାଧେ • ଶ୍ରୀ କୃଷ୍ଣ", 18, Color.rgb(153,75,108)));

        ImageView devotionalImage = new ImageView(this);
        devotionalImage.setImageResource(com.radhakelikunj.app.R.drawable.radha_krishna_guru);
        devotionalImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        devotionalImage.setContentDescription("ରାଧା କୃଷ୍ଣ ଓ ଗୁରୁଦେବଙ୍କ ଭକ୍ତିମୟ ଚିତ୍ର");
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, dp(300));
        imageParams.setMargins(0, dp(8), 0, dp(12));
        page.addView(devotionalImage, imageParams);
        page.addView(label("ଶ୍ରୀ ରାଧେ 🙏", 18, Color.rgb(107,36,72)));

        page.addView(label("ରାଧା ନାମ ଜପ", 22, Color.rgb(107,36,72)));
        page.addView(label("ରାଧେ ରାଧେ • ରାଧେ ରାଧେ", 20, Color.rgb(139,48,91)));
        Button play = button("▶ ନାମ ଜପ ଆରମ୍ଭ");
        play.setOnClickListener(v -> Toast.makeText(this, "ଅଡିଓ ଯୋଡ଼ାଯିବା ପରେ ଚାଲିବ", Toast.LENGTH_SHORT).show());
        page.addView(play);

        page.addView(label("୧୦୮ ମାଳା ଜପ", 22, Color.rgb(107,36,72)));
        counter = label("ଗଣନା: ୦ / ୧୦୮", 20, Color.rgb(70,45,58));
        page.addView(counter);
        Button jap = button("ରାଧେ ରାଧେ  +୧");
        jap.setOnClickListener(v -> {
            count = (count + 1) % 109;
            counter.setText("ଗଣନା: " + count + " / ୧୦୮");
            if (count == 108) Toast.makeText(this, "୧୦୮ ଜପ ସମ୍ପୂର୍ଣ୍ଣ 🙏", Toast.LENGTH_LONG).show();
        });
        page.addView(jap);
        Button reset = button("ପୁଣି ଆରମ୍ଭ କରନ୍ତୁ");
        reset.setOnClickListener(v -> { count = 0; counter.setText("ଗଣନା: ୦ / ୧୦୮"); });
        page.addView(reset);

        page.addView(label("ଭଜନ ଓ କୀର୍ତ୍ତନ", 21, Color.rgb(107,36,72)));
        page.addView(button("ଭଜନ ଶୁଣନ୍ତୁ"));
        page.addView(button("କୀର୍ତ୍ତନ ଶୁଣନ୍ତୁ"));
        page.addView(label("ଶ୍ରୀମଦ୍ ଭଗବଦ୍ ଗୀତା • ରାଧା-कୃଷ୍ଣ ଲୀଳା • ଦୈନିକ ଦର୍ଶନ", 16, Color.rgb(92,52,67)));
        page.addView(label("ଜୟ ଶ୍ରୀ ରାଧେ 🙏", 20, Color.rgb(107,36,72)));

        scroll.addView(page);
        setContentView(scroll);
    }
}
